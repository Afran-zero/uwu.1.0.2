<div class="container mt-5">
    <h1 class="text-center mb-4">Terms and Conditions</h1>
    <p>Welcome to UwU!</p>

    <p>By accessing and using this platform, you agree to comply with the following terms and conditions:</p>

    <ul>
        <li>You must use this platform responsibly and refrain from posting offensive or harmful content.</li>
        <li>Your account information must remain confidential and not shared with others.</li>
        <li>The platform reserves the right to suspend or terminate your account if you violate any terms.</li>
        <li>All content shared on this platform must respect copyright laws.</li>
    </ul>

    <h2>Your Data</h2>
    <p>By using this platform, you acknowledge and agree that your data will be used as per our privacy policy.Yet this project is a temporary asset . so your data is accessable. Please refrain from doing rough or private message </p>

    <h2>Changes to Terms</h2>
    <p>We reserve the right to update these terms at any time without prior notice.</p>

    <p>If you have any questions about these terms, feel free to contact at kaif.khan@northsouth.edu.</p>

    <a href="?" class="btn btn-primary mt-3">Go Back to Home</a>
</div>
