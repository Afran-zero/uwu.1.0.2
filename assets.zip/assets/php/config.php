<?php
session_start();
// mysqli database connection
const DB_NAME = 'uwu1.0.2';
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';